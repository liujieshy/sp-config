package com.jiudian.manage.service.ex;

public class ServiceExecption extends RuntimeException {

	public ServiceExecption() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ServiceExecption(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public ServiceExecption(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ServiceExecption(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ServiceExecption(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	

}
